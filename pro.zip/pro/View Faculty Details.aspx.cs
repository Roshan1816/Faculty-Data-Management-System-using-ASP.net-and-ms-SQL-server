﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace pro
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        SqlCommand command;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string connectionSttring = "Data Source=localhost;Initial Catalog=Faculty;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionSttring))
            {
                string Fid = TextBox1.Text;

                string query = "SELECT F.FACT_ID,FNAME,LNAME,GENDER,DATEOFBIRTH,PHONE_NO,E_MAIL,JOING_DATE,DESIGNATION,DEPT_ID,HOUSE_NO,STREET,CITY,STATE_,ZIP FROM Faculty_deatils F,ADDRESS_ A WHERE F.FACT_ID=@Fid AND F.FACT_ID=A.FACT_ID;";

                command = new SqlCommand(query, connection);

                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable data = new DataTable();
                adapter.SelectCommand.Parameters.AddWithValue("@Fid", Fid);
                adapter.Fill(data);

                if (data.Rows.Count > 0)
                {
                    GridView1.DataSource = data;
                    GridView1.DataBind();
                }
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("https://localhost:44334/Main%20page");
            Server.Transfer("https://localhost:44334/Main%20page");
        }
    }
}