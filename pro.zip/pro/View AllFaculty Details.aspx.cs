﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Xamarin.Forms;

namespace pro
{
    public partial class WebForm14 : System.Web.UI.Page
    {
        SqlCommand command;
        SqlCommand command1;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string connectionSttring = "Data Source=localhost;Initial Catalog=Faculty;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionSttring))
            {
                

                string query = "SELECT F.FACT_ID,FNAME,LNAME,GENDER,DATEOFBIRTH,PHONE_NO,E_MAIL,JOING_DATE,DESIGNATION,DEPT_ID,HOUSE_NO,STREET,CITY,STATE_,ZIP FROM Faculty_deatils F,ADDRESS_ A WHERE  F.FACT_ID=A.FACT_ID;";

                command = new SqlCommand(query, connection);

                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable data = new DataTable();
                adapter.Fill(data);

                if (data.Rows.Count > 0)
                {
                    GridView1.DataSource = data;
                    GridView1.DataBind();
                }
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string connectionSttring = "Data Source=localhost;Initial Catalog=Faculty;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionSttring))
            {

                string query = "SELECT P.FACT_ID,A.AWARD_TITLE,ORGANIZATION,AWARDED_DATE,PAPER_ID,P.PAPER_TITLE,PUBLISHED_DATE,PAPER_TYPE FROM AWARDS A,PAPERS P WHERE P.FACT_ID=A.FACT_ID";

                command = new SqlCommand(query, connection);


                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable data = new DataTable();
                adapter.Fill(data);

                if (data.Rows.Count > 0)
                {
                    GridView2.DataSource = data;
                    GridView2.DataBind();
                }

            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            string connectionSttring = "Data Source=localhost;Initial Catalog=Faculty;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionSttring))
            {

                string query = "SELECT F.FACT_ID,DEGREE,SPECIALIZATION,YEAR_OF_PASSING,F.INSTITUTE,W.WORK_EXP,JOB_ROLE,START__DATE,END__DATE FROM FACULTY_QUALIFICATION F,WORK_EXP W WHERE F.FACT_ID=W.FACT_ID";
                //string query1 = "SELECT FACT_ID FROM PAPERS";
                command = new SqlCommand(query, connection);
                //command1 = new SqlCommand(query1, connection);

                //connection.Open();
                //SqlDataReader reader = command1.ExecuteReader();
                //GridView2.DataSource = reader;
                //GridView2.DataBind();


                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable data = new DataTable();
                adapter.Fill(data);

                if (data.Rows.Count > 0)
                {
                    GridView3.DataSource = data;
                    GridView3.DataBind();
                }
            }
        }

    }
}