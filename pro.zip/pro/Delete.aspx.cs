﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace pro
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        SqlCommand command;
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnConfirmDelete_Click(object sender, EventArgs e)
        {
            lblConfirmation.Visible = true;
            btnConfirmDelete.Visible = true;
            btnCancelDelete.Visible = true;
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            lblConfirmation.Visible = true;
            btnConfirmDelete.Visible = true;
            btnCancelDelete.Visible = true;

            string Fid = TextBox1.Text;
            Perfromdelete(Fid);
        }
        protected void btnCancelDelete_Click(object sender, EventArgs e)
        {


            lblConfirmation.Visible = false;
            btnConfirmDelete.Visible = false;
            btnCancelDelete.Visible = false;
        }

        private void  Perfromdelete(string Fact_id)
        {
            string connectionSttring = "Data Source=localhost;Initial Catalog=Faculty;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionSttring))
            {
                
                string query = "DELETE FROM FACULTY_DEATILS WHERE FACT_ID= @Fid";
                command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Fid", Fact_id);

                connection.Open();
                int row=command.ExecuteNonQuery();
                if(row>0)
                {
                    MessageBox.Show("Data Sucessfully deleted","Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Response.Redirect(Request.Url.AbsoluteUri);
                }
                else
                {

                }
                connection.Close();
                Response.Redirect(Request.Url.AbsoluteUri);
            }
        }
    }
}