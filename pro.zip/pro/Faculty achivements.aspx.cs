﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using MessageBox = System.Windows.Forms.MessageBox;
using MessageBoxButtons = System.Windows.Forms.MessageBoxButtons;
using MessageBoxIcon = System.Windows.Forms.MessageBoxIcon;
//using System.Windows.Forms;
using Path = System.IO.Path;
using File = System.IO.File;
using System.Reflection;

namespace pro
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        SqlCommand command;
        SqlCommand command1;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            bool allFieldsFilled = true;

            foreach (Control control in form1.Controls)
            {
                if (control is TextBox )
                {
                    TextBox textBox = (TextBox)control;
                    if (string.IsNullOrEmpty(textBox.Text.Trim()))
                    {
                        allFieldsFilled = false;
                        break;
                    }
                }
                else if (control is TextBox dateTextBox)
                {
                    if (string.IsNullOrEmpty(dateTextBox.Text))
                    {
                        allFieldsFilled = false;
                        break;
                    }
                    else if (!DateTime.TryParse(dateTextBox.Text, out _))
                    {
                        allFieldsFilled = false;
                        break;
                    }
                }
            }
            if (allFieldsFilled)
            {
                // Process the form data
                string connectionSttring = "Data Source=localhost;Initial Catalog=Faculty;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionSttring))
                {
                    string Fid = TextBox1.Text;
                    string title = TextBox2.Text;
                    string Organization = TextBox3.Text;
                    DateTime DateAwarded = DateTime.Parse(id4.Value);
                    string paper_id = TextBox4.Text;
                    string P_title = TextBox5.Text;
                    DateTime DatePublished = DateTime.Parse(id5.Value);
                    string type = TextBox6.Text;
                    //string tempPath = Path.Combine(Server.MapPath("~/TempImages"), imageFile.FileName);
                    //imageFile.SaveAs(tempPath);
                    string tempPath1 = Path.Combine(Server.MapPath("~/TempImages"), imageFile1.FileName);
                    imageFile1.SaveAs(tempPath1);
                    //byte[] imageBytes = File.ReadAllBytes(tempPath);
                    byte[] imageBytes1 = File.ReadAllBytes(tempPath1);


                    string query = "INSERT INTO AWARDS(FACT_ID,AWARD_TITLE,ORGANIZATION,AWARDED_DATE) VALUES(@Fid,@title,@organization,@date)";
                    string query1 = "INSERT INTO PAPERS(FACT_ID,PAPER_ID,PAPER_TITLE,PUBLISHED_DATE,PAPER_TYPE,DOC) VALUES(@Fid,@Paper_id,@ptitle,@datePub,@type,@Doc)";
                    command = new SqlCommand(query, connection);
                    command1 = new SqlCommand(query1, connection);

                    command.Parameters.AddWithValue("@Fid", Fid);
                    command.Parameters.AddWithValue("@title", title);
                    command.Parameters.AddWithValue("@organization", Organization);
                    command.Parameters.AddWithValue("@date", DateAwarded);
                    //command.Parameters.AddWithValue("@Doc", imageBytes);

                    command1.Parameters.AddWithValue("@Fid", Fid);
                    command1.Parameters.AddWithValue("Paper_id", paper_id);
                    command1.Parameters.AddWithValue("@ptitle", P_title);
                    command1.Parameters.AddWithValue("@datePub", DatePublished);
                    command1.Parameters.AddWithValue("@type", type);
                    command1.Parameters.AddWithValue("@Doc", imageBytes1);

                    connection.Open();
                    int row1 = command.ExecuteNonQuery();
                    int row2 = command1.ExecuteNonQuery();

                    if (row1 > 0 && row2 > 0)
                    {
                        MessageBox.Show("Data Inserted Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Data not Inserted properly", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    //File.Delete(tempPath);
                    File.Delete(tempPath1);
                    connection.Close();
                    Response.Redirect(Request.Url.AbsoluteUri);
                }
            }
            else
            {
                // Display an error message or code
                MessageBox.Show("Data not Inserted properly all the Filed should be Entered", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Response.Redirect(Request.Url.AbsoluteUri);
            }            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("https://localhost:44334/Main%20page");
            Server.Transfer("https://localhost:44334/Main%20page");
        }
    }
}