﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Xamarin.Forms;

namespace pro
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        SqlCommand command;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string connectionSttring = "Data Source=localhost;Initial Catalog=Faculty;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionSttring))
            {
                string Fid = TextBox1.Text;

                string query = "SELECT F.FACT_ID,DEGREE,SPECIALIZATION,YEAR_OF_PASSING,F.INSTITUTE,W.WORK_EXP,JOB_ROLE,START__DATE,END__DATE FROM FACULTY_QUALIFICATION F,WORK_EXP W WHERE F.FACT_ID=W.FACT_ID AND F.FACT_ID=@Fid";

                command = new SqlCommand(query, connection);

                Literal1.Visible = true;
                Literal1.Text = "Faculty Qualification";


                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable data = new DataTable();
                adapter.SelectCommand.Parameters.AddWithValue("@Fid", Fid);
                adapter.Fill(data);

                if (data.Rows.Count > 0)
                {
                    GridView1.DataSource = data;
                    GridView1.DataBind();
                }
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("https://localhost:44334/Main%20page");
            Server.Transfer("https://localhost:44334/Main%20page");
        }






        private byte[] RetrieveFacultyImageDataFromDatabase(string connectionString, string facultyId)
        {
            byte[] imageData = null;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Replace with your actual query to retrieve image data based on faculty ID
                string query = "SELECT DOC FROM FACULTY_QUALIFICATION WHERE FACT_ID = @FacultyId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@FacultyId", facultyId);

                connection.Open();
                imageData = (byte[])command.ExecuteScalar();
            }
            return imageData;
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string facultyId = TextBox1.Text;

            if (!string.IsNullOrEmpty(facultyId))
            {
                // Replace with your connection string
                string connectionString = "Data Source=localhost;Initial Catalog=Faculty;Integrated Security=True";

                // Query the database to retrieve image data for the entered faculty ID
                byte[] facultyImageData = RetrieveFacultyImageDataFromDatabase(connectionString, facultyId);

                if (facultyImageData != null)
                {
                    string base64Image = Convert.ToBase64String(facultyImageData);
                    Image1.ImageUrl = "data:image/jpeg;base64," + base64Image;
                }
                else
                {
                    // Handle case where faculty image data is not found
                    Image1.ImageUrl = "";
                }
            }
        }
    }
}